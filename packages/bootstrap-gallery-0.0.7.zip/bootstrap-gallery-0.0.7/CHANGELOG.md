# bootstrap-gallery changelog

## 0.0.7 (2015-04-10)

* fixing disabled caption bug
* changing defaults to disabled captions

## 0.0.6 (2015-04-09)

* introducing caption functionality
* defining bootstrap-gallery mixin in less

## 0.0.5 (2014-03-17)

* only show Loading indicator if loading time is greater than options.indicatorThreshold
* Bugfix, Loading indicator shows up even if not loading on initial click.
* Introducing option to decide whether controls are inside image or always at the same position

## 0.0.4 (2014-03-16)

* Adding loading indicator

## 0.0.3 (2014-03-16)

* Fixing Firefox bug

## 0.0.2 (2014-03-09)

* Adding swipe functionality

## 0.0.1 (2014-03-08)

* basic functionality added
